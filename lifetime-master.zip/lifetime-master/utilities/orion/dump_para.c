#include "SIM_power.h"


int main(int argc, char **argv)
{
  SIM_power_dump_tech_para();

  exit(0);
}
