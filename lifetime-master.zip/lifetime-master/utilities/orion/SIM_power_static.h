#ifndef _SIM_POWER_STATIC_H
#define _SIM_POWER_STATIC_H

#include "SIM_power.h"

extern double NMOS_TAB[1];
extern double PMOS_TAB[1];
extern double NAND2_TAB[4];
extern double NOR2_TAB[4];

#endif	/* _SIM_POWER_STATIC_H */
