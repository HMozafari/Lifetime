/* 
   Copyright 2009 Carnegie Mellon University.
   
   This software developed under GRC contract 2008-HJ-1795 funded by
   the Semiconductor Research Corporation.
*/

#ifndef GREEDY_H_
#define GREEDY_H_

//#define GREEDY_COST(area, wl) (0.5*(area) + 0.5*(wl))
#define GREEDY_COST(area, wl) (area)

#endif
