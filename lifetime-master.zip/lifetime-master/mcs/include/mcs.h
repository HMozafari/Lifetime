/*                                                                              
   Copyright 2009 Carnegie Mellon University.                                   
                                                                                
   This software developed under GRC contract 2008-HJ-1795 funded by            
   the Semiconductor Research Corporation.                                      
*/

#ifndef MCS_H_
#define MCS_H_

//extern int mcsVerbosity;
//extern bool tempUpdate;
//extern bool buildFailures;

#endif /*MCS_H_*/
